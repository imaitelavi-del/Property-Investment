/* Estate Nexus - site logic (no backend) */
(function () {
  const D = window.EstateNexusData;
  if (!D) return;

  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.from((root || document).querySelectorAll(sel)); }

  function escapeHtml(str) {
    return String(str)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  function formatDate(iso) {
    try {
      const d = new Date(iso + "T00:00:00Z");
      const opts = { year: "numeric", month: "short", day: "2-digit" };
      return d.toLocaleDateString(undefined, opts);
    } catch {
      return iso;
    }
  }

  // Header / mobile nav
  const navToggle = qs("[data-nav-toggle]");
  const navMenu = qs("[data-nav-menu]");
  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      const open = navMenu.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    qsa("a", navMenu).forEach(a => a.addEventListener("click", () => {
      navMenu.classList.remove("is-open");
      navToggle.setAttribute("aria-expanded", "false");
    }));
  }

  // Inject company name/tagline
  qsa("[data-company-name]").forEach(el => el.textContent = D.company.name);
  qsa("[data-company-tagline]").forEach(el => el.textContent = D.company.tagline);

  // Footer
  const footer = qs("[data-footer]");
  if (footer) {
    const year = new Date().getFullYear();
    footer.innerHTML = `
      <div class="container">
        <div class="footerGrid">
          <div>
            <div class="brandRow">
              <div class="logoMark" aria-hidden="true"></div>
              <div>
                <div class="brandName">${escapeHtml(D.company.name)}</div>
                <div class="brandTag">${escapeHtml(D.company.tagline)}</div>
              </div>
            </div>
            <p class="smallMuted">Premium, delivery-focused development with a disciplined approach to risk, quality, and stakeholder confidence.</p>
          </div>
          <div>
            <div class="footerTitle">Contact</div>
            <ul class="footerList">
              <li><a href="mailto:${escapeHtml(D.company.email)}">${escapeHtml(D.company.email)}</a></li>
              <li><a href="tel:${escapeHtml(D.company.phone.replace(/\s/g,''))}">${escapeHtml(D.company.phone)}</a></li>
              <li>${escapeHtml(D.company.address)}</li>
            </ul>
          </div>
          <div>
            <div class="footerTitle">Social</div>
            <ul class="footerList">
              <li><a href="${escapeHtml(D.company.socials.linkedin)}" target="_blank" rel="noreferrer">LinkedIn</a></li>
              <li><a href="${escapeHtml(D.company.socials.instagram)}" target="_blank" rel="noreferrer">Instagram</a></li>
              <li><a href="${escapeHtml(D.company.socials.x)}" target="_blank" rel="noreferrer">X</a></li>
            </ul>
          </div>
        </div>
        <div class="footerBottom">
          <div class="smallMuted">© ${year} ${escapeHtml(D.company.name)}. All rights reserved.</div>
          <div class="smallMuted">Built as a default editable template.</div>
        </div>
      </div>
    `;
  }

  // Home stats
  const statsRoot = qs("[data-stats]");
  if (statsRoot) {
    statsRoot.innerHTML = D.stats.map(s => `
      <div class="statCard glass">
        <div class="statValue">${escapeHtml(s.value)}</div>
        <div class="statLabel">${escapeHtml(s.label)}</div>
      </div>
    `).join("");
  }

  // Featured projects
  const featuredRoot = qs("[data-featured-projects]");
  if (featuredRoot) {
    const featured = D.projects.slice(0, 6);
    featuredRoot.innerHTML = featured.map(p => projectCard(p)).join("");
  }

  // Projects listing with filters
  const listRoot = qs("[data-project-list]");
  if (listRoot) {
    const statusSel = qs("[data-filter-status]");
    const locSel = qs("[data-filter-location]");
    const typeSel = qs("[data-filter-type]");
    const searchInput = qs("[data-filter-search]");
    const countEl = qs("[data-project-count]");

    function unique(list) { return Array.from(new Set(list)).sort(); }

    if (statusSel) fillSelect(statusSel, ["All"].concat(unique(D.projects.map(p => p.status))));
    if (locSel) fillSelect(locSel, ["All"].concat(unique(D.projects.map(p => p.location))));
    if (typeSel) fillSelect(typeSel, ["All"].concat(unique(D.projects.map(p => p.type))));

    function applyFilters() {
      const s = statusSel ? statusSel.value : "All";
      const l = locSel ? locSel.value : "All";
      const t = typeSel ? typeSel.value : "All";
      const q = searchInput ? searchInput.value.trim().toLowerCase() : "";

      let items = D.projects.slice();
      if (s !== "All") items = items.filter(p => p.status === s);
      if (l !== "All") items = items.filter(p => p.location === l);
      if (t !== "All") items = items.filter(p => p.type === t);
      if (q) {
        items = items.filter(p =>
          (p.name + " " + p.location + " " + p.type + " " + (p.headline || "")).toLowerCase().includes(q)
        );
      }

      listRoot.innerHTML = items.map(p => projectCard(p)).join("");
      if (countEl) countEl.textContent = String(items.length);
    }

    [statusSel, locSel, typeSel].filter(Boolean).forEach(el => el.addEventListener("change", applyFilters));
    if (searchInput) searchInput.addEventListener("input", debounce(applyFilters, 150));

    applyFilters();
  }

  // Project detail
  const detailRoot = qs("[data-project-detail]");
  if (detailRoot) {
    const params = new URLSearchParams(window.location.search);
    const id = params.get("id") || "";
    const project = D.projects.find(p => p.id === id) || D.projects[0];

    const titleEl = qs("[data-project-title]");
    const crumbEl = qs("[data-project-crumb]");
    if (titleEl) titleEl.textContent = project.name;
    if (crumbEl) crumbEl.textContent = project.name;

    // Hero
    const heroImg = qs("[data-project-hero]");
    if (heroImg) {
      heroImg.src = project.hero;
      heroImg.alt = project.name + " hero image";
    }

    // Facts
    const factsRoot = qs("[data-project-facts]");
    if (factsRoot) {
      const f = project.facts || {};
      const facts = [
        ["Address", f.address || "—"],
        ["Status", project.status],
        ["Timeline", f.timeline || "—"],
        ["Units", f.units || "—"],
        ["Amenities", (f.amenities || []).join(", ") || "—"],
        ["Delivery", f.delivery || "—"],
      ];
      factsRoot.innerHTML = facts.map(([k, v]) => `
        <div class="factRow">
          <div class="factKey">${escapeHtml(k)}</div>
          <div class="factVal">${escapeHtml(v)}</div>
        </div>
      `).join("");
    }

    // Gallery
    const galleryRoot = qs("[data-project-gallery]");
    if (galleryRoot) {
      const imgs = (project.gallery || [project.hero]).slice(0, 6);
      galleryRoot.innerHTML = imgs.map((src, i) => `
        <button class="thumb glass" type="button" data-gallery-open="${i}">
          <img src="${escapeHtml(src)}" alt="${escapeHtml(project.name)} image ${i + 1}" loading="lazy" />
        </button>
      `).join("");

      const modal = qs("[data-gallery-modal]");
      const modalImg = qs("[data-gallery-image]");
      const closeBtn = qs("[data-gallery-close]");
      let activeIndex = 0;

      function openAt(i) {
        activeIndex = i;
        if (modal && modalImg) {
          modalImg.src = imgs[activeIndex];
          modalImg.alt = project.name + " image " + (activeIndex + 1);
          modal.classList.add("open");
          closeBtn && closeBtn.focus();
        }
      }

      function close() {
        modal && modal.classList.remove("open");
      }

      galleryRoot.addEventListener("click", (e) => {
        const btn = e.target.closest("[data-gallery-open]");
        if (!btn) return;
        openAt(parseInt(btn.getAttribute("data-gallery-open"), 10));
      });

      if (closeBtn) closeBtn.addEventListener("click", close);
      if (modal) modal.addEventListener("click", (e) => {
        if (e.target === modal) close();
      });
      document.addEventListener("keydown", (e) => {
        if (!modal || !modal.classList.contains("open")) return;
        if (e.key === "Escape") close();
        if (e.key === "ArrowRight") openAt((activeIndex + 1) % imgs.length);
        if (e.key === "ArrowLeft") openAt((activeIndex - 1 + imgs.length) % imgs.length);
      });
    }

    // Map placeholder (accessible)
    const mapBox = qs("[data-map-box]");
    if (mapBox) {
      mapBox.innerHTML = `
        <div class="mapInner">
          <div class="mapBadge">Map</div>
          <div class="mapText">
            <div class="h4">Location preview</div>
            <div class="smallMuted">Embed a map here later (Google Maps / Mapbox). For now this is a placeholder to keep the layout and content structure.</div>
          </div>
        </div>
      `;
    }

    // Related projects
    const relatedRoot = qs("[data-related-projects]");
    if (relatedRoot) {
      const related = D.projects.filter(p => p.id !== project.id).slice(0, 3);
      relatedRoot.innerHTML = related.map(p => projectCard(p)).join("");
    }

    // Inquiry form
    wireForm("[data-inquiry-form]");
  }

  // News list
  const newsRoot = qs("[data-news-list]");
  if (newsRoot) {
    const catSel = qs("[data-news-category]");
    const search = qs("[data-news-search]");
    const countEl = qs("[data-news-count]");

    const categories = Array.from(new Set(D.posts.map(p => p.category))).sort();
    if (catSel) fillSelect(catSel, ["All"].concat(categories));

    function apply() {
      const c = catSel ? catSel.value : "All";
      const q = search ? search.value.trim().toLowerCase() : "";
      let items = D.posts.slice().sort((a, b) => (a.date < b.date ? 1 : -1));
      if (c !== "All") items = items.filter(p => p.category === c);
      if (q) items = items.filter(p => (p.title + " " + p.excerpt).toLowerCase().includes(q));
      newsRoot.innerHTML = items.map(p => postCard(p)).join("");
      if (countEl) countEl.textContent = String(items.length);
    }

    if (catSel) catSel.addEventListener("change", apply);
    if (search) search.addEventListener("input", debounce(apply, 150));
    apply();
  }

  // Post detail
  const postRoot = qs("[data-post-detail]");
  if (postRoot) {
    const params = new URLSearchParams(window.location.search);
    const id = params.get("id") || "";
    const post = D.posts.find(p => p.id === id) || D.posts[0];

    const titleEl = qs("[data-post-title]");
    const metaEl = qs("[data-post-meta]");
    const heroEl = qs("[data-post-hero]");
    const bodyEl = qs("[data-post-body]");

    if (titleEl) titleEl.textContent = post.title;
    if (metaEl) metaEl.textContent = `${formatDate(post.date)} · ${post.category}`;
    if (heroEl) { heroEl.src = post.hero; heroEl.alt = post.title + " image"; }
    if (bodyEl) {
      bodyEl.innerHTML = `
        <p class="lead">${escapeHtml(post.excerpt)}</p>
        <div class="prose">
          <p>${escapeHtml(post.content)}</p>
          <h3>Make this real</h3>
          <p>Replace the placeholder content with your approach, diagrams, delivery examples, and internal lessons learned.</p>
          <h3>Suggested sections</h3>
          <ul>
            <li>Context and objective</li>
            <li>Approach and timeline</li>
            <li>Risk controls</li>
            <li>Outcome and evidence</li>
          </ul>
        </div>
      `;
    }

    const relatedRoot = qs("[data-related-posts]");
    if (relatedRoot) {
      const related = D.posts.filter(p => p.id !== post.id).slice(0, 3);
      relatedRoot.innerHTML = related.map(p => postCard(p)).join("");
    }
  }

  // Contact form
  wireForm("[data-contact-form]");

  // Helpers
  function fillSelect(sel, options) {
    sel.innerHTML = options.map(o => `<option value="${escapeHtml(o)}">${escapeHtml(o)}</option>`).join("");
  }

  function debounce(fn, wait) {
    let t;
    return function () {
      window.clearTimeout(t);
      const args = arguments;
      t = window.setTimeout(() => fn.apply(null, args), wait);
    };
  }

  function projectCard(p) {
    const statusPill = pill(p.status);
    const href = `project.html?id=${encodeURIComponent(p.id)}`;
    return `
      <article class="card glass">
        <a class="cardMedia" href="${href}" aria-label="Open ${escapeHtml(p.name)}">
          <img src="${escapeHtml(p.hero)}" alt="${escapeHtml(p.name)}" loading="lazy" />
          <div class="cardOverlay"></div>
          <div class="cardPills">
            ${statusPill}
            <span class="pill">${escapeHtml(p.location)}</span>
            <span class="pill">${escapeHtml(p.type)}</span>
          </div>
        </a>
        <div class="cardBody">
          <h3 class="cardTitle"><a href="${href}">${escapeHtml(p.name)}</a></h3>
          <p class="cardText">${escapeHtml(p.headline || "")}</p>
          <div class="cardActions">
            <a class="btn btnGhost" href="${href}">View details</a>
            <a class="btn btnPrimary" href="contact.html?project=${encodeURIComponent(p.name)}">Enquire</a>
          </div>
        </div>
      </article>
    `;
  }

  function postCard(p) {
    const href = `post.html?id=${encodeURIComponent(p.id)}`;
    return `
      <article class="card glass">
        <a class="cardMedia" href="${href}" aria-label="Open ${escapeHtml(p.title)}">
          <img src="${escapeHtml(p.hero)}" alt="${escapeHtml(p.title)}" loading="lazy" />
          <div class="cardOverlay"></div>
          <div class="cardPills">
            <span class="pill">${escapeHtml(p.category)}</span>
            <span class="pill">${escapeHtml(formatDate(p.date))}</span>
          </div>
        </a>
        <div class="cardBody">
          <h3 class="cardTitle"><a href="${href}">${escapeHtml(p.title)}</a></h3>
          <p class="cardText">${escapeHtml(p.excerpt)}</p>
          <div class="cardActions">
            <a class="btn btnPrimary" href="${href}">Read</a>
          </div>
        </div>
      </article>
    `;
  }

  function pill(status) {
    const s = (status || "").toLowerCase();
    const cls = s.includes("complete") ? "pill pillOk" : (s.includes("under") ? "pill pillWarn" : "pill");
    return `<span class="${cls}">${escapeHtml(status)}</span>`;
  }

  function wireForm(selector) {
    const form = qs(selector);
    if (!form) return;

    const status = form.querySelector("[data-form-status]");
    const submit = form.querySelector("button[type='submit']");

    // Prefill project query param
    const params = new URLSearchParams(window.location.search);
    const project = params.get("project");
    const projectField = form.querySelector("[name='project']");
    if (project && projectField && !projectField.value) projectField.value = project;

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      clearInlineErrors(form);

      const values = Object.fromEntries(new FormData(form).entries());
      const errors = validate(values, form);

      if (Object.keys(errors).length) {
        showInlineErrors(form, errors);
        setStatus(status, "Please correct the highlighted fields.", "error");
        return;
      }

      setStatus(status, "Sending...", "busy");
      if (submit) submit.disabled = true;

      // Simulate submission, no email sending.
      await sleep(650);

      const succeed = Math.random() > 0.08; // 92% success
      if (succeed) {
        setStatus(status, "Thank you. Your message has been received. We will respond shortly.", "ok");
        form.reset();
      } else {
        setStatus(status, "Submission failed. Please try again.", "error");
      }
      if (submit) submit.disabled = false;
    });
  }

  function validate(values, form) {
    const errors = {};
    const required = qsa("[data-required]", form);
    required.forEach((el) => {
      const name = el.getAttribute("name");
      if (!name) return;
      const v = String(values[name] || "").trim();
      if (!v) errors[name] = "This field is required.";
    });

    if (values.email) {
      const v = String(values.email).trim();
      const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
      if (!ok) errors.email = "Enter a valid email address.";
    }

    if (values.phone) {
      const v = String(values.phone).trim();
      if (v && v.replace(/[^0-9]/g, "").length < 8) errors.phone = "Enter a valid phone number.";
    }

    if (values.message) {
      const v = String(values.message).trim();
      if (v && v.length < 20) errors.message = "Please provide a little more detail (20+ characters).";
    }

    return errors;
  }

  function showInlineErrors(form, errors) {
    Object.entries(errors).forEach(([name, msg]) => {
      const field = form.querySelector(`[name='${CSS.escape(name)}']`);
      if (!field) return;
      field.setAttribute("aria-invalid", "true");
      const holder = field.closest(".field") || field.parentElement;
      if (!holder) return;
      let err = holder.querySelector(".fieldError");
      if (!err) {
        err = document.createElement("div");
        err.className = "fieldError";
        holder.appendChild(err);
      }
      err.textContent = msg;
    });
  }

  function clearInlineErrors(form) {
    qsa("[aria-invalid='true']", form).forEach(el => el.removeAttribute("aria-invalid"));
    qsa(".fieldError", form).forEach(el => el.remove());
  }

  function setStatus(el, text, kind) {
    if (!el) return;
    el.textContent = text;
    el.classList.remove("ok", "error", "busy");
    if (kind) el.classList.add(kind);
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
})();
