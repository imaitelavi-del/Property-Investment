// Editable content file (no backend required)
// Update projects/posts here to change site content.

window.EstateNexusData = {
  company: {
    name: "Estate Nexus Developments",
    tagline: "Design-led developments. Delivered with discipline.",
    email: "hello@estatenexus.example",
    phone: "+44 (0)20 0000 0000",
    address: "Marylebone, London, W1",
    socials: {
      linkedin: "https://www.linkedin.com/",
      instagram: "https://www.instagram.com/",
      x: "https://x.com/"
    }
  },
  stats: [
    { label: "Years delivering", value: "12+" },
    { label: "Homes and units", value: "350+" },
    { label: "Active locations", value: "6" },
    { label: "Partner network", value: "40+" }
  ],
  projects: [
    {
      id: "riverlight",
      name: "Riverlight Mews",
      status: "Completed",
      location: "London",
      type: "Residential",
      headline: "Boutique mews homes with calm, premium finishes.",
      hero: "https://images.unsplash.com/photo-1501183638710-841dd1904471?auto=format&fit=crop&w=1600&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1501183638710-841dd1904471?auto=format&fit=crop&w=1600&q=80",
        "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=1600&q=80",
        "https://images.unsplash.com/photo-1502005229762-cf1b2da7c5d6?auto=format&fit=crop&w=1600&q=80",
        "https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=1600&q=80"
      ],
      facts: {
        address: "Marylebone, London W1",
        timeline: "2019-2021",
        units: "14",
        amenities: "Concierge, private terraces, secure cycle storage"
      },
      mapQuery: "Marylebone, London",
      brochureUrl: "#"
    },
    {
      id: "canvasyard",
      name: "Canvas Yard",
      status: "Under Construction",
      location: "Manchester",
      type: "Mixed Use",
      headline: "A flexible live-work neighbourhood built around public space.",
      hero: "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1600&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=1600&q=80",
        "https://images.unsplash.com/photo-1527030280862-64139fba04ca?auto=format&fit=crop&w=1600&q=80",
        "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1600&q=80"
      ],
      facts: {
        address: "Northern Quarter, Manchester",
        timeline: "2024-2026",
        units: "88",
        amenities: "Retail frontage, co-working lounge, roof garden"
      },
      mapQuery: "Northern Quarter, Manchester",
      brochureUrl: "#"
    },
    {
      id: "harborline",
      name: "Harborline Logistics",
      status: "Planned",
      location: "Bristol",
      type: "Industrial",
      headline: "High-spec last-mile warehousing with low-carbon infrastructure.",
      hero: "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1600&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1600&q=80",
        "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=80",
        "https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1600&q=80"
      ],
      facts: {
        address: "Avonmouth, Bristol",
        timeline: "2026-2028",
        units: "3 units, 210k sq ft",
        amenities: "EV-ready bays, PV array, enhanced yard depth"
      },
      mapQuery: "Avonmouth, Bristol",
      brochureUrl: "#"
    }
  ],
  services: [
    {
      title: "Development Management",
      body: "End-to-end delivery from concept to practical completion, including cost, programme, and stakeholder governance."
    },
    {
      title: "Acquisitions and Feasibility",
      body: "Market-led underwriting, appraisal modelling, planning risk review, and partner alignment to de-risk investment decisions."
    },
    {
      title: "Planning Strategy",
      body: "Proactive planning engagement, consultant coordination, design development, and submission management."
    },
    {
      title: "Construction Management",
      body: "Procurement strategy, contractor management, QA, change control, and H&S oversight."
    },
    {
      title: "Sales and Lettings Support",
      body: "Go-to-market positioning, collateral, unit mix refinement, and handover readiness."
    }
  ],
  posts: [
    {
      id: "design-to-delivery",
      title: "From Design to Delivery: Maintaining Value Through Construction",
      date: "2026-01-05",
      category: "Delivery",
      excerpt: "A practical lens on specification control, programme risk, and the small decisions that protect end value.",
      hero: "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?auto=format&fit=crop&w=1600&q=80",
      content: "Strong projects are not only conceived well; they are executed with discipline. In this default post, replace this text with your own insights, case studies, and lessons learned."
    },
    {
      id: "planning-confidence",
      title: "Planning Confidence: Reducing Risk Before You Submit",
      date: "2025-12-18",
      category: "Planning",
      excerpt: "How to structure early engagement so the submission has momentum and credibility.",
      hero: "https://images.unsplash.com/photo-1552326459-403b5a8a8f73?auto=format&fit=crop&w=1600&q=80",
      content: "This is placeholder content designed to be edited later. Add your planning approach, stakeholder map, and example timelines."
    },
    {
      id: "low-carbon-ops",
      title: "Low-Carbon Operations: Designing for Real Performance",
      date: "2025-11-27",
      category: "Sustainability",
      excerpt: "Beyond embodied carbon: how operational decisions influence long-term asset outcomes.",
      hero: "https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1600&q=80",
      content: "Replace with your sustainability commitments, performance targets, and delivery examples."
    }
  ]
};
